var express = require("express");
var router = express.Router();
var bcrypt = require("bcrypt");
var uid2 = require("uid2");

var userModel = require('../models/userModel')

router.post('/importprofil', async function (req, res, next) {

  var admin = [
    {
      user: "dev",
      firstName: "Benjamin",
      lastName: "D'ONOFRIO",
      society: "BeniDiego.js",
      email: "",
      emailPro: "benidiegopro@gmail.com",
      password: "",
      address: "",
      phoneNumber: "0699757781",
      web: "https://benit.fr",
      instagram: "",
      facebook: "",
    },
    {
      user: "admin",
      firstName: "Maxime",
      lastName: "Turpault",
      society: "",
      email: "maxime.turpault92@gmail.com",
      emailPro: "turpaultphotographie@gmail.com",
      password: "",
      address: "",
      phoneNumber: "0770102320",
      web: "https://maximeturpault.benit.fr",
      instagram: "https://www.instagram.com/maximeturpault/",
      facebook: "https://www.facebook.com/profile.php?id=100012629315440",
    },
  ]

  for (let i = 0; i < admin.length; i++) {
    var newAdmin = new userModel({
      token: uid2(32),
      user: admin[i].user,
      firstName: admin[i].firstName,
      lastName: admin[i].lastName,
      society: admin[i].society,
      email: admin[i].email,
      emailPro: admin[i].emailPro,
      password: bcrypt.hashSync(admin[i].password, 10),
      address: admin[i].address,
      phoneNumber: admin[i].phoneNumber,
      web: admin[i].web,
      instagram: admin[i].instagram,
      facebook: admin[i].facebook,
    });

    var adminSave = await newAdmin.save();
  }

  res.json({ adminSave });
});

module.exports = router;